const express = require('express');
const cors = require('cors');
const crypto = require('crypto');
const forge = require('node-forge');

const app = express();
app.use(cors());
app.use(express.json());

// Génération clés RSA serveur
const serverKeyPair = forge.pki.rsa.generateKeyPair({ bits: 2048 });
const serverPublicKeyPem = forge.pki.publicKeyToPem(serverKeyPair.publicKey);

// Stockage session par IP
const sessions = {};

// 1. Envoi clé publique serveur
app.get('/get_server_pub_key', (req, res) => {
    res.json({ 
        server_pub_key: Buffer.from(serverPublicKeyPem).toString('base64') 
    });
});

// 2. Génération challenge
app.get('/challenge', (req, res) => {
    const clientIP = req.ip;
    const challenge = crypto.randomBytes(32).toString('hex');
    sessions[clientIP] = { challenge };
    res.json({ challenge });
});

// 3. Authentification client
app.post('/auth', (req, res) => {
    const clientIP = req.ip;
    const { client_pub_key, signed_challenge_b64 } = req.body;

    try {
        if (!sessions[clientIP]?.challenge) {
            return res.status(400).json({ error: 'Challenge non initialisé' });
        }

        const clientPubKeyPem = Buffer.from(client_pub_key, 'base64').toString();
        const clientPublicKey = forge.pki.publicKeyFromPem(clientPubKeyPem);
        
        const signature = Buffer.from(signed_challenge_b64, 'base64');
        const challengeHex = sessions[clientIP].challenge;
        const md = forge.md.sha256.create();
        md.update(challengeHex, 'utf8');

        const isValid = clientPublicKey.verify(
            md.digest().bytes(),
            signature.toString('binary'),
            'RSASSA-PKCS1-V1_5'
        );

        if (isValid) {
            sessions[clientIP].clientPublicKey = clientPublicKey;
            res.json({ message: 'Authentification réussie !' });
        } else {
            res.status(401).json({ error: 'Signature invalide' });
        }
    } catch (err) {
        res.status(500).json({ 
            error: 'Erreur vérification signature',
            details: err.message 
        });
    }
});

// 4. Échange de messages (CORRIGÉ)
app.post('/exchange', (req, res) => {
    const clientIP = req.ip;
    const { encrypted_msg_b64 } = req.body;

    try {
        if (!sessions[clientIP]?.clientPublicKey) {
            return res.status(403).json({ error: 'Client non authentifié' });
        }

        // Conversion base64 -> buffer binaire
        const encryptedBuffer = Buffer.from(encrypted_msg_b64, 'base64');
        
        // Déchiffrement avec OAEP/SHA-256
        const decrypted = serverKeyPair.privateKey.decrypt(
            encryptedBuffer.toString('binary'),
            'RSA-OAEP',
            {
                md: forge.md.sha256.create(),
                mgf1: {
                    md: forge.md.sha256.create()
                }
            }
        );

        console.log('📨 Message reçu:', decrypted);

        // Chiffrement réponse avec SHA-256
        const response = "Accusé réception: " + decrypted;
        const encryptedResponse = sessions[clientIP].clientPublicKey.encrypt(
            response, 
            'RSA-OAEP',
            {
                md: forge.md.sha256.create(),
                mgf1: {
                    md: forge.md.sha256.create()
                }
            }
        );
        
        res.json({ 
            response_b64: Buffer.from(encryptedResponse, 'binary').toString('base64') 
        });
    } catch (err) {
        res.status(500).json({ 
            error: 'Erreur traitement message',
            details: err.message 
        });
    }
});

const PORT = 5000;
app.listen(PORT, () => console.log(`🚀 Serveur: http://localhost:${PORT}`));