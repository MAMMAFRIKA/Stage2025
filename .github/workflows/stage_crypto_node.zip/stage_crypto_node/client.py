import requests
import base64
from cryptography.hazmat.primitives import serialization, hashes
from cryptography.hazmat.primitives.asymmetric import rsa, padding
from cryptography.hazmat.backends import default_backend

BASE_URL = "http://127.0.0.1:5000"

# Génération clés RSA client
client_private_key = rsa.generate_private_key(
    public_exponent=65537,
    key_size=2048,
    backend=default_backend()
)
client_public_key = client_private_key.public_key()

# Encodage clé publique client
client_pub_key_pem = client_public_key.public_bytes(
    encoding=serialization.Encoding.PEM,
    format=serialization.PublicFormat.SubjectPublicKeyInfo
)
client_pub_key_b64 = base64.b64encode(client_pub_key_pem).decode()

# 1. Récupération clé publique serveur
res = requests.get(f"{BASE_URL}/get_server_pub_key")
server_pub_key_b64 = res.json().get("server_pub_key")
server_pub_key_pem = base64.b64decode(server_pub_key_b64)
server_pub_key = serialization.load_pem_public_key(server_pub_key_pem)
print("🔑 Clé publique serveur reçue")

# 2. Récupération challenge
res = requests.get(f"{BASE_URL}/challenge")
challenge_hex = res.json().get("challenge")
print(f"🔒 Challenge reçu: {challenge_hex}")

# 3. Signature du challenge (PKCS1v15)
signature = client_private_key.sign(
    challenge_hex.encode('utf-8'),
    padding.PKCS1v15(),
    hashes.SHA256()
)
signature_b64 = base64.b64encode(signature).decode()

# 4. Authentification
res = requests.post(f"{BASE_URL}/auth", json={
    "client_pub_key": client_pub_key_b64,
    "signed_challenge_b64": signature_b64
})
auth_response = res.json()
print("🔐 Réponse authentification:", auth_response)

if res.status_code == 200 and "réussie" in auth_response.get("message", ""):
    try:
        while True:
            message = input("💬 Message à envoyer: ").encode()
            
            if len(message) > 190:
                print("❌ Message trop long (max 190 caractères)")
                continue  # redemande un message
            
            encrypted = server_pub_key.encrypt(
                message,
                padding.OAEP(
                    mgf=padding.MGF1(algorithm=hashes.SHA256()),
                    algorithm=hashes.SHA256(),
                    label=None
                )
            )
            encrypted_b64 = base64.b64encode(encrypted).decode()

            res = requests.post(f"{BASE_URL}/exchange", json={
                "encrypted_msg_b64": encrypted_b64
            })
            
            if res.ok:
                encrypted_response_b64 = res.json().get("response_b64")
                encrypted_response = base64.b64decode(encrypted_response_b64)
                
                response = client_private_key.decrypt(
                    encrypted_response,
                    padding.OAEP(
                        mgf=padding.MGF1(algorithm=hashes.SHA256()),
                        algorithm=hashes.SHA256(),
                        label=None
                    )
                )
                print("📬 Réponse serveur:", response.decode('latin1'))
            else:
                print("❌ Erreur échange:", res.text)

    except KeyboardInterrupt:
        print("\n⛔ Interruption détectée, arrêt du script.")

else:
    print("⛔ Échec authentification")
